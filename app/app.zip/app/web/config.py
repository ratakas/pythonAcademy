DEBUG = True
PORT = 8000
HOST = "0.0.0.0"
THREADED = True
SQLALCHEMY_ECHO = True
SQLALCHEMY_TRACK_MODIFICATIONS = True
SECRET_KEY = "SOME SECRET"
# PostgreSQL
#SQLALCHEMY_DATABASE_URI = "sqlite:////Users/ratakas/Documents/docker/app/database/prueba.db"
SQLALCHEMY_DATABASE_URI ='sqlite:////bd-data/prueba.db'
